docker-compose -f docker-compose-finalExam.yaml down
